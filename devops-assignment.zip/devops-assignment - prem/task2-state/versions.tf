terraform {
  required_version = ">= 1.5.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.0"
    }
  }

  backend "s3" {
    bucket         = "mybucket"
    key            = "devops-assignment/task1/terraform.tfstate"
    region         = "us-east-1"
    dynamodb_table = "devops-assignment-terraform-lock"
    encrypt        = true
  }
}
provider "aws" {
  region = "us-east-1"
}
