# Task 4 � Least-Privilege CI Policy

## Purpose

This policy is intended for the `ci` user created in Task 3.

The CI pipeline is allowed to:

1. Push Docker images to one specific ECR repository.
2. Register a new ECS task definition and update one specific ECS service.
3. Read build artifacts from one specific S3 bucket.

The policy intentionally does not provide broad administrative or service-level permissions.

## ECR

Allowed actions:

- ecr:BatchCheckLayerAvailability
- ecr:CompleteLayerUpload
- ecr:InitiateLayerUpload
- ecr:PutImage
- ecr:UploadLayerPart
- ecr:GetAuthorizationToken

The image push permissions are restricted to:

arn:aws:ecr:ap-south-1:000000000000:repository/devops-app

`ecr:GetAuthorizationToken` uses Resource `*` because this action does not support repository-level resource permissions.

## ECS

Allowed actions:

- ecs:DescribeServices
- ecs:DescribeTaskDefinition
- ecs:RegisterTaskDefinition
- ecs:UpdateService

The policy is scoped to the specific ECS service and task-definition family used by the deployment.

The CI user is not given general ECS administrative permissions.

## S3

The CI pipeline can read build artifacts from:

arn:aws:s3:::devops-build-artifacts

Allowed actions:

- s3:GetObject
- s3:GetObjectVersion
- s3:ListBucket

The policy deliberately does not allow:

- s3:PutObject
- s3:DeleteObject
- s3:PutBucket*
- s3:DeleteBucket

Therefore the CI pipeline cannot modify or delete objects in the build-artifact bucket through this policy.

## Deliberately left out

The following broad permissions were deliberately not granted:

- iam:*
- ec2:*
- ecs:*
- ecr:*
- s3:*
- sts:AssumeRole
- CloudFormation permissions
- Lambda permissions
- DynamoDB permissions
- KMS administration permissions
- CloudWatch administration permissions

The policy does not use broad managed policies such as PowerUserAccess, AdministratorAccess, AmazonECSFullAccess, AmazonEC2ContainerRegistryFullAccess, or AmazonS3FullAccess.

The intent is to give the CI pipeline only the permissions needed for the specified build and deployment workflow.
