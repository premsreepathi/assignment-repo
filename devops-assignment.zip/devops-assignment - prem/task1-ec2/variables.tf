variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "us-east-1"
}

variable "instances" {
  description = "EC2 instance configurations"
  type = map(object({
    instance_type = string
    root_volume = object({
      type = string
      size = number
    })
    key_name = string
  }))
}