# Task 1 � EC2

## Overview

This task creates an EC2 instance using Terraform.

The Terraform configuration separates provider configuration, input variables, EC2 resources, and outputs into different files.

## Files

- `versions.tf` � Terraform and AWS provider requirements.
- `variables.tf` � Input variable definitions.
- `main.tf` � EC2 instance and related AWS resources.
- `outputs.tf` � Values displayed after Terraform apply.
- `terraform.tfvars` � Values supplied for the Terraform variables.

## Terraform Commands Used

Initialize the Terraform working directory:

terraform init

Format the Terraform configuration:

terraform fmt

Validate the configuration:

terraform validate

Review the resources Terraform plans to create:

terraform plan

Create the resources:

terraform apply

Display Terraform outputs:

terraform output

## AWS Authentication

AWS credentials should not be hard-coded in Terraform configuration files.

Authentication should be provided through AWS CLI configuration, environment variables, IAM roles, or another supported credential mechanism.

## Resource Management

Terraform keeps track of resources using its state file. The state should be protected and should not be committed to source control when it contains sensitive information.

## Cleanup

When the EC2 instance is no longer required, the resources can be removed with:

terraform destroy
