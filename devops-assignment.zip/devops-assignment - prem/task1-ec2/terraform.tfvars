aws_region = "us-east-1"

instances = {
  app-server = {
    instance_type = "t3.micro"

    root_volume = {
      type = "gp3"
      size = 20
    }

    key_name = "devops-key"
  }

  web-server = {
    instance_type = "t3.small"

    root_volume = {
      type = "gp3"
      size = 30
    }

    key_name = "web-key"
  }

  database-server = {
    instance_type = "t3.medium"

    root_volume = {
      type = "io2"
      size = 50
    }

    key_name = "database-key"
  }

  build-server = {
    instance_type = "t3.large"

    root_volume = {
      type = "gp3"
      size = 80
    }

    key_name = "build-key"
  }

  monitoring-server = {
    instance_type = "t3a.medium"

    root_volume = {
      type = "gp2"
      size = 40
    }

    key_name = "monitoring-key"
  }
}