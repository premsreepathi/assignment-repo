data "aws_ami" "amazon_linux" {
  most_recent = true

  owners = ["amazon"]

  filter {
    name   = "name"
    values = ["al2023-ami-*-x86_64"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

resource "aws_instance" "regular" {
  for_each = {
    for name, config in var.instances :
    name => config
    if name != "database-server"
  }

  ami           = data.aws_ami.amazon_linux.id
  instance_type = each.value.instance_type
  key_name      = each.value.key_name

  root_block_device {
    volume_type = each.value.root_volume.type
    volume_size = each.value.root_volume.size
  }

  tags = {
    Name        = each.key
    Environment = "DevOps"
    Owner       = "DevOps-Team"
  }
}

resource "aws_instance" "database" {
  for_each = {
    for name, config in var.instances :
    name => config
    if name == "database-server"
  }

  ami           = data.aws_ami.amazon_linux.id
  instance_type = each.value.instance_type
  key_name      = each.value.key_name

  root_block_device {
    volume_type = each.value.root_volume.type
    volume_size = each.value.root_volume.size
  }

  lifecycle {
    prevent_destroy = true
  }

  tags = {
    Name        = each.key
    Environment = "DevOps"
    Owner       = "DevOps-Team"
  }
}