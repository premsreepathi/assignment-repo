# Task 5 � Find and Fix the Bug

## What was wrong?

The trust policy for roleC was using this ARN:

arn:aws:iam::000000000000:user/roleB

That ARN identifies an IAM user named `roleB`.

However, `roleB` is an IAM role, not an IAM user. IAM role ARNs use `/role/` instead of `/user/`.

The correct ARN is:

arn:aws:iam::000000000000:role/roleB

Because the trust policy was trusting an IAM user ARN that did not represent the roleB role, roleB was not a trusted principal for roleC. Therefore, when roleB attempted to call sts:AssumeRole on roleC, the request could not satisfy roleC's trust policy.

## Fixed configuration

The principal in roleC's trust policy was changed from:

arn:aws:iam::000000000000:user/roleB

to:

arn:aws:iam::000000000000:role/roleB

The trust policy therefore specifically trusts roleB from Account A.

## Trust policy vs permissions policy

The roleC trust policy controls who can assume roleC.

The roleC_s3 permissions policy controls what roleC can do after it has been assumed.

The S3 policy in this exercise allows roleC to use S3. It does not make roleB trusted by itself.

For roleB to successfully assume roleC, both sides matter:

1. roleC must trust roleB.
2. roleB must have permission to call sts:AssumeRole on roleC.

Task 3 gives roleB that sts:AssumeRole permission.

## Important ARN difference

IAM user:

arn:aws:iam::ACCOUNT_ID:user/USERNAME

IAM role:

arn:aws:iam::ACCOUNT_ID:role/ROLE_NAME

The original configuration used the user ARN format for a role, which caused the cross-account assume-role relationship to fail.
