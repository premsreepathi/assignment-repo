output "group1_users" {
  description = "CLI/programmatic users"
  value       = [for user in aws_iam_user.group1_users : user.name]
}

output "group2_users" {
  description = "Console and CLI users"
  value       = [for user in aws_iam_user.group2_users : user.name]
}

output "roleA_arn" {
  description = "Account A roleA ARN"
  value       = aws_iam_role.roleA.arn
}

output "roleB_arn" {
  description = "Account A roleB ARN"
  value       = aws_iam_role.roleB.arn
}

output "roleC_arn" {
  description = "Account B roleC ARN"
  value       = aws_iam_role.roleC.arn
}

output "s3_bucket_name" {
  description = "S3 bucket accessible by roleC"
  value       = aws_s3_bucket.roleC_bucket.bucket
}

output "s3_bucket_arn" {
  description = "S3 bucket ARN"
  value       = aws_s3_bucket.roleC_bucket.arn
}
