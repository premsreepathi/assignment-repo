# Task 3 � Multi-Account IAM & Cross-Account Access

## Account A

Account A ID:

000000000000

Resources created in Account A:

- `group1`
  - `engine`
  - `ci`
  - Intended for CLI/programmatic access.

- `group2`
  - `alice`
  - `bob`
  - Intended for console and CLI access.

- `roleA`
  - Administrative access to AWS services except IAM.
  - The policy allows AWS service actions generally but explicitly denies `iam:*`.

- `roleB`
  - Has only `sts:AssumeRole` permission.
  - The permission is restricted to `roleC` in Account B.

## Account B

Account B ID:

111111111111

Resources created in Account B:

- `roleC`
  - Can be assumed by `roleB` from Account A.
  - Has access to the specific S3 bucket used by this task.

- S3 bucket
  - Used as the resource protected by `roleC`.

## Cross-Account Access

The intended flow is:

Account A `roleB`
        |
        | sts:AssumeRole
        v
Account B `roleC`
        |
        v
Specific S3 bucket

The trust policy on `roleC` specifically trusts:

arn:aws:iam::000000000000:role/roleB

It does not trust the entire Account A root principal.

For the cross-account operation to succeed, two permissions are required:

1. `roleC` must trust `roleB`.
2. `roleB` must have permission to call `sts:AssumeRole` on `roleC`.

## 1. Would you actually give engine and ci IAM users with access keys in a real production setup?

Generally, I would avoid creating long-lived IAM users and permanent access keys for CI or other workloads in a real production environment.

Instead, I would use temporary credentials through IAM roles.

For AWS workloads, services such as EC2 or ECS can use IAM roles to obtain temporary credentials. For CI/CD systems that support it, federation such as OIDC can be used so the CI system can assume an AWS IAM role without storing long-lived AWS access keys.

The IAM users `engine` and `ci` are created here because the assignment explicitly requires them.

## 2. Why does it matter whether roleC trusts the whole Account A root or roleB's specific ARN?

Trusting the whole Account A root establishes a broader trust relationship with Account A.

A principal from Account A may potentially assume the role if the principal also has the necessary `sts:AssumeRole` permission and satisfies the other conditions of the trust policy.

Trusting the specific role ARN:

arn:aws:iam::000000000000:role/roleB

makes the intended trust relationship much narrower. It identifies `roleB` as the principal that roleC is intended to trust rather than trusting Account A broadly.

This is important for least-privilege access and matches the assignment requirement that roleC be assumable by roleB and not by other principals in Account A.

## IAM Role vs IAM User ARN

An IAM user ARN has this format:

arn:aws:iam::ACCOUNT_ID:user/USERNAME

An IAM role ARN has this format:

arn:aws:iam::ACCOUNT_ID:role/ROLE_NAME

Therefore, `roleB` must be referenced as:

arn:aws:iam::000000000000:role/roleB

and not:

arn:aws:iam::000000000000:user/roleB

## Terraform Commands

The following commands were used to manage the configuration:

terraform fmt
terraform init
terraform validate
terraform plan
terraform apply
terraform output

When the resources are no longer required, they can be removed with:

terraform destroy
