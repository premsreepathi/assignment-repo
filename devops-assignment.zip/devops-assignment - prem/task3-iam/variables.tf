variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "ap-south-1"
}

variable "account_a_id" {
  description = "AWS Account A ID"
  type        = string
}

variable "account_b_id" {
  description = "AWS Account B ID"
  type        = string
}

variable "s3_bucket_name" {
  description = "S3 bucket used by roleC"
  type        = string
}

variable "group1_users" {
  description = "Users requiring programmatic access"
  type        = list(string)
  default     = ["engine", "ci"]
}

variable "group2_users" {
  description = "Users requiring console and CLI access"
  type        = list(string)
  default     = ["alice", "bob"]
}
