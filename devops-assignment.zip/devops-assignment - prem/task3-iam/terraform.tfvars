aws_region     = "ap-south-1"
account_a_id   = "000000000000"
account_b_id   = "111111111111"
s3_bucket_name = "devops-task3-prem-20261003"

group1_users = ["engine", "ci"]
group2_users = ["alice", "bob"]
