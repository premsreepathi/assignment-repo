terraform {
  required_version = ">= 1.5.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.0"
    }
  }
}

provider "aws" {
  alias   = "account_a"
  region  = var.aws_region
  profile = "account-a"
}

provider "aws" {
  alias   = "account_b"
  region  = var.aws_region
  profile = "account-b"
}
