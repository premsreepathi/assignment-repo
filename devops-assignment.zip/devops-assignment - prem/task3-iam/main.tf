#
# ============================================================
# ACCOUNT A
# ============================================================
#

# -------------------------
# Group 1 - CLI only
# -------------------------

resource "aws_iam_group" "group1" {
  provider = aws.account_a
  name     = "group1"
}

resource "aws_iam_user" "group1_users" {
  provider = aws.account_a

  for_each = toset(var.group1_users)

  name = each.value
}

resource "aws_iam_group_membership" "group1_membership" {
  provider = aws.account_a

  name  = "group1-membership"
  group = aws_iam_group.group1.name

  users = [
    for user in aws_iam_user.group1_users : user.name
  ]
}

# -------------------------
# Group 2 - Console + CLI
# -------------------------

resource "aws_iam_group" "group2" {
  provider = aws.account_a
  name     = "group2"
}

resource "aws_iam_user" "group2_users" {
  provider = aws.account_a

  for_each = toset(var.group2_users)

  name = each.value
}

resource "aws_iam_group_membership" "group2_membership" {
  provider = aws.account_a

  name  = "group2-membership"
  group = aws_iam_group.group2.name

  users = [
    for user in aws_iam_user.group2_users : user.name
  ]
}

#
# ============================================================
# roleA - Administrative access EXCEPT IAM
# ============================================================
#

resource "aws_iam_role" "roleA" {
  provider = aws.account_a
  name     = "roleA"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"

    Statement = [
      {
        Effect = "Allow"

        Principal = {
          AWS = "arn:aws:iam::${var.account_a_id}:root"
        }

        Action = "sts:AssumeRole"
      }
    ]
  })
}

resource "aws_iam_role_policy" "roleA_policy" {
  provider = aws.account_a
  name     = "roleA-admin-except-iam"
  role     = aws_iam_role.roleA.id

  policy = jsonencode({
    Version = "2012-10-17"

    Statement = [
      {
        Sid    = "AllowEverything"
        Effect = "Allow"

        Action   = "*"
        Resource = "*"
      },
      {
        Sid    = "DenyIAM"
        Effect = "Deny"

        Action   = "iam:*"
        Resource = "*"
      }
    ]
  })
}

#
# ============================================================
# roleB - ONLY assume roleC
# ============================================================
#

resource "aws_iam_role" "roleB" {
  provider = aws.account_a
  name     = "roleB"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"

    Statement = [
      {
        Effect = "Allow"

        Principal = {
          AWS = "arn:aws:iam::${var.account_a_id}:root"
        }

        Action = "sts:AssumeRole"
      }
    ]
  })
}

#
# roleB has exactly one permission:
# sts:AssumeRole on roleC in Account B
#

resource "aws_iam_role_policy" "roleB_policy" {
  provider = aws.account_a
  name     = "roleB-assume-roleC"
  role     = aws_iam_role.roleB.id

  policy = jsonencode({
    Version = "2012-10-17"

    Statement = [
      {
        Effect = "Allow"

        Action = [
          "sts:AssumeRole"
        ]

        Resource = aws_iam_role.roleC.arn
      }
    ]
  })
}

#
# ============================================================
# ACCOUNT B
# ============================================================
#

# -------------------------
# S3 bucket
# -------------------------

resource "aws_s3_bucket" "roleC_bucket" {
  provider = aws.account_b

  bucket = var.s3_bucket_name

  tags = {
    Project = "DevOps-Assignment"
    Task    = "Task3-IAM"
  }
}

#
# ============================================================
# roleC in Account B
# ============================================================
#

resource "aws_iam_role" "roleC" {
  provider = aws.account_b
  name     = "roleC"

  #
  # IMPORTANT:
  # Only roleB from Account A is trusted.
  #
  assume_role_policy = jsonencode({
    Version = "2012-10-17"

    Statement = [
      {
        Effect = "Allow"

        Principal = {
          AWS = "arn:aws:iam::${var.account_a_id}:role/roleB"
        }

        Action = "sts:AssumeRole"
      }
    ]
  })
}

#
# roleC has full S3 access ONLY to the named bucket.
#

resource "aws_iam_role_policy" "roleC_policy" {
  provider = aws.account_b
  name     = "roleC-s3-bucket-access"
  role     = aws_iam_role.roleC.id

  policy = jsonencode({
    Version = "2012-10-17"

    Statement = [
      {
        Sid    = "BucketAccess"
        Effect = "Allow"

        Action = "s3:*"

        Resource = aws_s3_bucket.roleC_bucket.arn
      },
      {
        Sid    = "ObjectAccess"
        Effect = "Allow"

        Action = "s3:*"

        Resource = "${aws_s3_bucket.roleC_bucket.arn}/*"
      }
    ]
  })
}
